import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Search, Filter, ChevronDown } from 'lucide-react';

interface Application {
  id: number;
  jobTitle: string;
  company: string;
  location: string;
  appliedDate: string;
  status: 'pending' | 'reviewed' | 'interview' | 'rejected' | 'accepted';
  lastActivity: string;
}

const mockApplications: Application[] = [
  {
    id: 1,
    jobTitle: "Lead Aesthetic Nurse",
    company: "Elite Medical Spa",
    location: "Beverly Hills, CA",
    appliedDate: "2024-03-15",
    status: "interview",
    lastActivity: "Interview scheduled for March 20"
  },
  {
    id: 2,
    jobTitle: "Senior Injector",
    company: "Luxury Aesthetics",
    location: "Los Angeles, CA",
    appliedDate: "2024-03-14",
    status: "pending",
    lastActivity: "Application under review"
  },
  {
    id: 3,
    jobTitle: "Aesthetic Nurse Practitioner",
    company: "Beauty Med",
    location: "Santa Monica, CA",
    appliedDate: "2024-03-13",
    status: "reviewed",
    lastActivity: "Application reviewed by employer"
  }
];

const statusColors = {
  pending: 'bg-yellow-100 text-yellow-700',
  reviewed: 'bg-blue-100 text-blue-700',
  interview: 'bg-green-100 text-green-700',
  rejected: 'bg-red-100 text-red-700',
  accepted: 'bg-purple-100 text-purple-700'
};

export function InjectorApplicationsPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  const filteredApplications = mockApplications.filter(app => {
    const matchesSearch = 
      app.jobTitle.toLowerCase().includes(searchTerm.toLowerCase()) ||
      app.company.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || app.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  return (
    <main className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex items-center gap-4 mb-8">
        <Link
          to="/injector/dashboard"
          className="inline-flex items-center gap-2 text-gray-600 hover:text-gray-900"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Dashboard
        </Link>
      </div>

      <div className="bg-white rounded-lg shadow-md">
        <div className="p-6 border-b">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <h1 className="text-2xl font-bold text-gray-900">My Applications</h1>
            
            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative">
                <Search className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search applications..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-rose-500 focus:border-transparent w-full md:w-64"
                />
              </div>

              <div className="relative">
                <Filter className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="pl-10 pr-8 py-2 border rounded-lg focus:ring-2 focus:ring-rose-500 focus:border-transparent appearance-none"
                >
                  <option value="all">All Status</option>
                  <option value="pending">Pending</option>
                  <option value="reviewed">Reviewed</option>
                  <option value="interview">Interview</option>
                  <option value="rejected">Rejected</option>
                  <option value="accepted">Accepted</option>
                </select>
                <ChevronDown className="w-4 h-4 text-gray-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>
            </div>
          </div>
        </div>

        <div className="divide-y divide-gray-200">
          {filteredApplications.map((application) => (
            <div key={application.id} className="p-6">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div>
                  <h2 className="text-xl font-semibold text-gray-900 mb-2">
                    {application.jobTitle}
                  </h2>
                  <p className="text-gray-600 mb-2">{application.company} • {application.location}</p>
                  <div className="flex flex-wrap gap-4 text-sm">
                    <span className="text-gray-500">
                      Applied {new Date(application.appliedDate).toLocaleDateString()}
                    </span>
                    <span className={`px-3 py-1 rounded-full text-sm font-medium ${statusColors[application.status]}`}>
                      {application.status.charAt(0).toUpperCase() + application.status.slice(1)}
                    </span>
                  </div>
                </div>
                <div className="flex flex-col items-end gap-2">
                  <Link
                    to={`/jobs/${application.id}`}
                    className="text-rose-500 hover:text-rose-600"
                  >
                    View Job
                  </Link>
                  <p className="text-sm text-gray-500">{application.lastActivity}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </main>
  );
}