import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Briefcase, 
  Users, 
  BarChart2,
  Star,
  ArrowRight,
  TrendingUp,
  Eye,
  Clock,
  MapPin
} from 'lucide-react';
import { AnalyticsChart } from '../components/AnalyticsChart';

const mockAnalytics = {
  views: [65, 75, 82, 78, 69, 80, 95],
  applications: [12, 15, 18, 14, 11, 16, 20],
  dates: ['Mar 10', 'Mar 11', 'Mar 12', 'Mar 13', 'Mar 14', 'Mar 15', 'Mar 16']
};

const topLocations = [
  { city: 'Los Angeles, CA', count: 45 },
  { city: 'New York, NY', count: 38 },
  { city: 'Miami, FL', count: 32 },
  { city: 'Dallas, TX', count: 28 }
];

export function EmployerDashboardPage() {
  return (
    <main className="max-w-7xl mx-auto px-4 py-8">
      {/* Dashboard Header */}
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900 mb-2">Employer Dashboard</h1>
        <p className="text-gray-600">Track your job listings and applications</p>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Link
          to="/employers/active-jobs"
          className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow group"
        >
          <div className="flex items-center justify-between mb-4">
            <Briefcase className="w-8 h-8 text-rose-500" />
            <ArrowRight className="w-5 h-5 text-gray-400 group-hover:translate-x-1 transition-transform" />
          </div>
          <p className="text-sm text-gray-600 mb-1">Active Jobs</p>
          <p className="text-2xl font-bold text-gray-900">3</p>
        </Link>

        <Link
          to="/employers/applications"
          className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow group"
        >
          <div className="flex items-center justify-between mb-4">
            <Users className="w-8 h-8 text-rose-500" />
            <ArrowRight className="w-5 h-5 text-gray-400 group-hover:translate-x-1 transition-transform" />
          </div>
          <p className="text-sm text-gray-600 mb-1">Total Applications</p>
          <p className="text-2xl font-bold text-gray-900">25</p>
        </Link>

        <Link
          to="/employers/new-applications"
          className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow group"
        >
          <div className="flex items-center justify-between mb-4">
            <BarChart2 className="w-8 h-8 text-rose-500" />
            <ArrowRight className="w-5 h-5 text-gray-400 group-hover:translate-x-1 transition-transform" />
          </div>
          <p className="text-sm text-gray-600 mb-1">New Today</p>
          <p className="text-2xl font-bold text-gray-900">5</p>
        </Link>

        <Link
          to="/employers/shortlisted"
          className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow group"
        >
          <div className="flex items-center justify-between mb-4">
            <Star className="w-8 h-8 text-rose-500" />
            <ArrowRight className="w-5 h-5 text-gray-400 group-hover:translate-x-1 transition-transform" />
          </div>
          <p className="text-sm text-gray-600 mb-1">Shortlisted</p>
          <p className="text-2xl font-bold text-gray-900">2</p>
        </Link>
      </div>

      {/* Analytics Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
        <div className="lg:col-span-2 bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-semibold text-gray-900">Performance Overview</h2>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-rose-500"></div>
                <span className="text-sm text-gray-600">Views</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-purple-500"></div>
                <span className="text-sm text-gray-600">Applications</span>
              </div>
            </div>
          </div>
          <AnalyticsChart data={mockAnalytics} />
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-6">Key Metrics</h2>
          <div className="space-y-6">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-rose-100 rounded-lg">
                <Eye className="w-6 h-6 text-rose-500" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Average Views/Day</p>
                <p className="text-xl font-bold text-gray-900">78</p>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <div className="p-3 bg-purple-100 rounded-lg">
                <TrendingUp className="w-6 h-6 text-purple-500" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Application Rate</p>
                <p className="text-xl font-bold text-gray-900">22%</p>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <div className="p-3 bg-blue-100 rounded-lg">
                <Clock className="w-6 h-6 text-blue-500" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Avg. Time to Apply</p>
                <p className="text-xl font-bold text-gray-900">2.5 days</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Location Analytics */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-6">Top Applicant Locations</h2>
          <div className="space-y-4">
            {topLocations.map((location, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <MapPin className="w-5 h-5 text-gray-400" />
                  <span className="text-gray-900">{location.city}</span>
                </div>
                <span className="text-gray-600">{location.count} applicants</span>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-6">Quick Actions</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Link
              to="/employers/post-job"
              className="btn btn-primary text-center"
            >
              Post New Job
            </Link>
            <Link
              to="/employers/applications"
              className="btn btn-secondary text-center"
            >
              Review Applications
            </Link>
            <Link
              to="/employers/shortlisted"
              className="btn btn-secondary text-center"
            >
              View Shortlisted
            </Link>
          </div>
        </div>
      </div>
    </main>
  );
}