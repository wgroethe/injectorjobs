import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  ArrowLeft, 
  User, 
  Mail, 
  Lock, 
  Bell, 
  Shield,
  Eye,
  Briefcase,
  GraduationCap,
  Award,
  Instagram,
  Save
} from 'lucide-react';
import { supabase } from '../lib/supabase';

interface ProfileStats {
  viewsLastWeek: number;
  viewsLastMonth: number;
  totalApplications: number;
  savedJobs: number;
}

export function AccountSettingsPage() {
  const [activeTab, setActiveTab] = useState('profile');
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [stats, setStats] = useState<ProfileStats>({
    viewsLastWeek: 0,
    viewsLastMonth: 0,
    totalApplications: 0,
    savedJobs: 0
  });

  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    licenseNumber: '',
    licenseState: '',
    certifications: [] as string[],
    education: '',
    graduationYear: '',
    yearsExperience: '',
    specialties: [] as string[],
    instagram: '',
    emailNotifications: {
      applications: true,
      messages: true,
      interviews: true,
      jobAlerts: true
    }
  });

  useEffect(() => {
    loadUserData();
    loadProfileStats();
  }, []);

  const loadUserData = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data: profile } = await supabase
        .from('profiles')
        .select('*')
        .eq('user_id', user.id)
        .single();

      if (profile) {
        setFormData({
          ...formData,
          ...profile,
          emailNotifications: profile.email_notifications || formData.emailNotifications
        });
      }
    } catch (error) {
      console.error('Error loading user data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const loadProfileStats = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      // Get profile views
      const { data: weekViews } = await supabase.rpc(
        'get_profile_views_count',
        { profile_id: user.id, days: 7 }
      );

      const { data: monthViews } = await supabase.rpc(
        'get_profile_views_count',
        { profile_id: user.id, days: 30 }
      );

      // Get applications count
      const { count: applicationsCount } = await supabase
        .from('applications')
        .select('*', { count: 'exact' })
        .eq('user_id', user.id);

      // Get saved jobs count
      const { count: savedJobsCount } = await supabase
        .from('saved_jobs')
        .select('*', { count: 'exact' })
        .eq('user_id', user.id);

      setStats({
        viewsLastWeek: weekViews || 0,
        viewsLastMonth: monthViews || 0,
        totalApplications: applicationsCount || 0,
        savedJobs: savedJobsCount || 0
      });
    } catch (error) {
      console.error('Error loading profile stats:', error);
    }
  };

  const handleSave = async () => {
    try {
      setIsSaving(true);
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { error } = await supabase
        .from('profiles')
        .upsert({
          user_id: user.id,
          ...formData,
          email_notifications: formData.emailNotifications,
          updated_at: new Date().toISOString()
        });

      if (error) throw error;
      alert('Settings saved successfully!');
    } catch (error) {
      console.error('Error saving settings:', error);
      alert('Failed to save settings. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) {
    return <div className="text-center py-12">Loading...</div>;
  }

  return (
    <main className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex items-center gap-4 mb-8">
        <Link
          to="/injector/dashboard"
          className="inline-flex items-center gap-2 text-gray-600 hover:text-gray-900"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Dashboard
        </Link>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Sidebar */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg shadow-md p-6">
            <nav className="space-y-2">
              <button
                onClick={() => setActiveTab('profile')}
                className={`w-full text-left px-4 py-2 rounded-lg flex items-center gap-2 ${
                  activeTab === 'profile' 
                    ? 'bg-rose-50 text-rose-600' 
                    : 'text-gray-600 hover:bg-gray-50'
                }`}
              >
                <User className="w-5 h-5" />
                Profile
              </button>
              <button
                onClick={() => setActiveTab('credentials')}
                className={`w-full text-left px-4 py-2 rounded-lg flex items-center gap-2 ${
                  activeTab === 'credentials' 
                    ? 'bg-rose-50 text-rose-600' 
                    : 'text-gray-600 hover:bg-gray-50'
                }`}
              >
                <Award className="w-5 h-5" />
                Credentials
              </button>
              <button
                onClick={() => setActiveTab('notifications')}
                className={`w-full text-left px-4 py-2 rounded-lg flex items-center gap-2 ${
                  activeTab === 'notifications' 
                    ? 'bg-rose-50 text-rose-600' 
                    : 'text-gray-600 hover:bg-gray-50'
                }`}
              >
                <Bell className="w-5 h-5" />
                Notifications
              </button>
              <button
                onClick={() => setActiveTab('privacy')}
                className={`w-full text-left px-4 py-2 rounded-lg flex items-center gap-2 ${
                  activeTab === 'privacy' 
                    ? 'bg-rose-50 text-rose-600' 
                    : 'text-gray-600 hover:bg-gray-50'
                }`}
              >
                <Shield className="w-5 h-5" />
                Privacy
              </button>
            </nav>

            {/* Profile Stats */}
            <div className="mt-8 pt-8 border-t">
              <h3 className="text-sm font-medium text-gray-900 mb-4">Profile Stats</h3>
              <div className="space-y-4">
                <div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-500">Profile views (7 days)</span>
                    <span className="font-medium text-gray-900">{stats.viewsLastWeek}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm mt-1">
                    <span className="text-gray-500">Profile views (30 days)</span>
                    <span className="font-medium text-gray-900">{stats.viewsLastMonth}</span>
                  </div>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-500">Total applications</span>
                  <span className="font-medium text-gray-900">{stats.totalApplications}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-500">Saved jobs</span>
                  <span className="font-medium text-gray-900">{stats.savedJobs}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="lg:col-span-3">
          <div className="bg-white rounded-lg shadow-md p-6">
            {activeTab === 'profile' && (
              <div className="space-y-6">
                <h2 className="text-xl font-semibold text-gray-900">Profile Information</h2>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      First Name
                    </label>
                    <input
                      type="text"
                      value={formData.firstName}
                      onChange={(e) => setFormData(prev => ({ ...prev, firstName: e.target.value }))}
                      className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-rose-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Last Name
                    </label>
                    <input
                      type="text"
                      value={formData.lastName}
                      onChange={(e) => setFormData(prev => ({ ...prev, lastName: e.target.value }))}
                      className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-rose-500 focus:border-transparent"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Email Address
                  </label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                    className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-rose-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                    className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-rose-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Instagram Handle
                  </label>
                  <div className="relative">
                    <Instagram className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={formData.instagram}
                      onChange={(e) => setFormData(prev => ({ ...prev, instagram: e.target.value.replace('@', '') }))}
                      className="w-full pl-10 pr-4 py-2 rounded-lg border focus:ring-2 focus:ring-rose-500 focus:border-transparent"
                      placeholder="@username"
                    />
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'credentials' && (
              <div className="space-y-6">
                <h2 className="text-xl font-semibold text-gray-900">Professional Credentials</h2>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      License Number
                    </label>
                    <input
                      type="text"
                      value={formData.licenseNumber}
                      onChange={(e) => setFormData(prev => ({ ...prev, licenseNumber: e.target.value }))}
                      className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-rose-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      State of License
                    </label>
                    <input
                      type="text"
                      value={formData.licenseState}
                      onChange={(e) => setFormData(prev => ({ ...prev, licenseState: e.target.value }))}
                      className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-rose-500 focus:border-transparent"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Education
                  </label>
                  <input
                    type="text"
                    value={formData.education}
                    onChange={(e) => setFormData(prev => ({ ...prev, education: e.target.value }))}
                    className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-rose-500 focus:border-transparent"
                    placeholder="e.g., BSN, University of California"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Years of Experience
                  </label>
                  <input
                    type="number"
                    value={formData.yearsExperience}
                    onChange={(e) => setFormData(prev => ({ ...prev, yearsExperience: e.target.value }))}
                    className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-rose-500 focus:border-transparent"
                  />
                </div>
              </div>
            )}

            {activeTab === 'notifications' && (
              <div className="space-y-6">
                <h2 className="text-xl font-semibold text-gray-900">Email Notifications</h2>
                
                <div className="space-y-4">
                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={formData.emailNotifications.applications}
                      onChange={(e) => setFormData(prev => ({
                        ...prev,
                        emailNotifications: {
                          ...prev.emailNotifications,
                          applications: e.target.checked
                        }
                      }))}
                      className="rounded text-rose-500 focus:ring-rose-400"
                    />
                    <span className="text-gray-700">Application updates</span>
                  </label>
                  
                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={formData.emailNotifications.messages}
                      onChange={(e) => setFormData(prev => ({
                        ...prev,
                        emailNotifications: {
                          ...prev.emailNotifications,
                          messages: e.target.checked
                        }
                      }))}
                      className="rounded text-rose-500 focus:ring-rose-400"
                    />
                    <span className="text-gray-700">New messages</span>
                  </label>
                  
                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={formData.emailNotifications.interviews}
                      onChange={(e) => setFormData(prev => ({
                        ...prev,
                        emailNotifications: {
                          ...prev.emailNotifications,
                          interviews: e.target.checked
                        }
                      }))}
                      className="rounded text-rose-500 focus:ring-rose-400"
                    />
                    <span className="text-gray-700">Interview reminders</span>
                  </label>
                  
                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={formData.emailNotifications.jobAlerts}
                      onChange={(e) => setFormData(prev => ({
                        ...prev,
                        emailNotifications: {
                          ...prev.emailNotifications,
                          jobAlerts: e.target.checked
                        }
                      }))}
                      className="rounded text-rose-500 focus:ring-rose-400"
                    />
                    <span className="text-gray-700">Job alerts</span>
                  </label>
                </div>
              </div>
            )}

            {activeTab === 'privacy' && (
              <div className="space-y-6">
                <h2 className="text-xl font-semibold text-gray-900">Privacy Settings</h2>
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-medium text-gray-900">Profile Visibility</h3>
                      <p className="text-sm text-gray-500">Control who can view your profile</p>
                    </div>
                    <select className="px-4 py-2 rounded-lg border focus:ring-2 focus:ring-rose-500 focus:border-transparent">
                      <option value="public">Public</option>
                      <option value="employers">Employers Only</option>
                      <option value="private">Private</option>
                    </select>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-medium text-gray-900">Profile Activity</h3>
                      <p className="text-sm text-gray-500">Show your activity status to others</p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input type="checkbox" className="sr-only peer" />
                      <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-rose-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-rose-500"></div>
                    </label>
                  </div>
                </div>
              </div>
            )}

            <div className="mt-8 pt-6 border-t">
              <button
                onClick={handleSave}
                disabled={isSaving}
                className="btn btn-primary w-full md:w-auto flex items-center justify-center gap-2"
              >
                <Save className="w-4 h-4" />
                {isSaving ? 'Saving...' : 'Save Changes'}
              </button>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}