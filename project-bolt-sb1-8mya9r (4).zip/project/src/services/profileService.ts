import { supabase } from '../lib/supabase';

export async function trackProfileView(profileId: string, source: string = 'direct') {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    // Don't track if viewing own profile
    if (user.id === profileId) return;

    const { error } = await supabase
      .from('profile_views')
      .insert([{
        profile_id: profileId,
        viewer_id: user.id,
        source
      }]);

    if (error) throw error;
  } catch (error) {
    console.error('Error tracking profile view:', error);
  }
}

export async function getProfileViewsCount(profileId: string, days: number = 7) {
  try {
    const { data, error } = await supabase.rpc(
      'get_profile_views_count',
      { profile_id: profileId, days }
    );

    if (error) throw error;
    return data;
  } catch (error) {
    console.error('Error getting profile views:', error);
    return 0;
  }
}